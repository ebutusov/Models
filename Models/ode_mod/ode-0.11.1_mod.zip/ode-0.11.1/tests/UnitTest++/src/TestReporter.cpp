#include "TestReporter.h"

namespace UnitTest {


TestReporter::~TestReporter()
{
}

}
